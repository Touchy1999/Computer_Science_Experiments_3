# 計算機科学実験4 プログラム検証

[![Build Status](https://travis-ci.org/tyage/experiment-4-ocaml.svg?branch=master)](https://travis-ci.org/tyage/experiment-4-ocaml)

http://www.fos.kuis.kyoto-u.ac.jp/~nishida/classes/isle4fp2014/

## How to test

```sh
opam install ocamlfind ounit re
```

### Test exercise

```sh
make test-exercise
```

### Test interpreter

```sh
make test-interpreter
```
