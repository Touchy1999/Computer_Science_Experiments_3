let rec f x = x + 1
in
f 3;;
