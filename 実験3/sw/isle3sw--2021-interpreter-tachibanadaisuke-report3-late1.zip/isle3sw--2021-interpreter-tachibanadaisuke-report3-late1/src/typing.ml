open Syntax

exception Error of string

let err s = raise (Error s)

(* Type Environment *)
type tyenv = ty Environment.t

(*Exercise4.3.2 : 型変数と型のペアのリストで表される型代入を表す型*)
type subst = (tyvar * ty) list

(*Exercise4.3.2 : 末尾の型代入から、自身より前の型代入に適用していき、それにより新しく出来た型代入を型変数に適用する*)
let rec subst_type s typ =
  let rec resolve_type s = function
      TyVar v -> (try List.assoc v s with Not_found -> TyVar v)
    | TyFun (ty1, ty2) -> TyFun (resolve_type s ty1, resolve_type s ty2)
    | a -> a in
  let rec resolve_subst = function
      [] -> []
    | (id, typ) :: rest -> let new_subst = resolve_subst rest in
        ((id, resolve_type new_subst typ) :: new_subst) in
  resolve_type (resolve_subst s) typ

(*Exercise4.3.2 : 型代入に関する型、関数*)
let rec subst_eqs s eqs = match eqs with
    [] -> []
  | (ty1, ty2) :: rest -> (subst_type s ty1, subst_type s ty2) :: (subst_eqs s rest)

(*Exercise4.3.6 : 型代入を型の等式集合に変換*)
let rec eqs_of_subst s = match s with
    [] -> []
  | (tyvar, ty) :: rest -> (TyVar tyvar, ty) :: eqs_of_subst rest


(*Exercise4.3.3 : 単一化アルゴリズム*)
let rec unify = function
    (*u[phi] = phi*)
    [] -> []
  | (ty1, ty2) :: rest -> (match ty1, ty2 with
      (*u({(tau,tau)} + X') = u(X')*)
      TyInt, TyInt | TyBool, TyBool -> unify rest
      (*u({(tau11 -> 12 = tau21 -> tau22)} + X') = u({tau11 = tau21, tau12 = tau22} + X')*)
    | TyFun (ty11, ty12), TyFun (ty21, ty22) -> unify ((ty11, ty21) :: (ty12, ty22) :: rest)
    | TyVar var1, TyVar var2 ->
      if var1 = var2 then unify rest
      else let eqs = [(var1, ty2)] in
        eqs @ (unify (subst_eqs eqs rest))
      (*u({(alpha, tau)} + X') or u({(tau, alpha)} + X')*)
    | TyVar var, ty | ty, TyVar var ->
      (*occur check*)
      if MySet.member var (Syntax.freevar_ty ty) then err ("type err")
      else let eqs = [(var, ty)] in
        eqs @ (unify (subst_eqs eqs rest))
      (*otherwise*)
    | _, _ -> err ("type err"))

(*Exercise 4.3.5 : 演算子 op が生成すべき制約集合と返り値の型を記述*)
let ty_prim op ty1 ty2 = match op with
    Plus -> ([(ty1, TyInt); (ty2, TyInt)], TyInt)
  | Mult -> ([(ty1, TyInt); (ty2, TyInt)], TyInt)
  | Lt -> ([(ty1, TyInt); (ty2, TyInt)], TyBool)
  | Seki -> ([(ty1, TyBool); (ty2, TyBool)], TyBool)
  | Wa -> ([(ty1, TyBool); (ty2, TyBool)], TyBool)

let rec ty_exp tyenv exp = 
  match exp with
    Var x -> 
      (try ([],Environment.lookup x tyenv) with
          Environment.Not_bound -> err ("variable not bound: " ^ x))
  | ILit _ -> ([],TyInt)
  | BLit _ -> ([],TyBool)
  | BinOp (op, exp1, exp2) ->
      let (s1, ty1) = ty_exp tyenv exp1 in
      let (s2, ty2) = ty_exp tyenv exp2 in
      let (eqs3, ty) = ty_prim op ty1 ty2 in
	  (* s1 と s2 を等式制約の集合に変換して，eqs3 と合わせる *)
      let eqs = (eqs_of_subst s1) @ (eqs_of_subst s2) @ eqs3 in
	  (* 全体の制約をもう一度解く．*)
      let s3 = unify eqs in (s3, subst_type s3 ty)
  | IfExp (exp1, exp2, exp3) ->
      let (s1, ty1) = ty_exp tyenv exp1 in
      let (s2, ty2) = ty_exp tyenv exp2 in
      let (s3, ty3) = ty_exp tyenv exp3 in
      let eqs = (eqs_of_subst s1) @ (eqs_of_subst s2) @ (eqs_of_subst s3) @ 
        [(ty1, TyBool)] @ [(ty2, ty3)] in
      let s4 = unify eqs in (s4, subst_type s4 ty3)
  | LetExp (id, exp1, exp2) ->
      let (s1, ty1) = ty_exp tyenv exp1 in
      let (s2, ty2) = ty_exp (Environment.extend id ty1 tyenv) exp2 in
      let domty = TyVar (fresh_tyvar ()) in
      let eqs = (eqs_of_subst s1) @ (eqs_of_subst s2) @ [(domty, ty1)] in
      let s3 = unify eqs in
      (s3, subst_type s3 ty2)
  | FunExp (id, exp) ->
      (* id の型を表す fresh な型変数を生成 *)
      let domty = TyVar (fresh_tyvar ()) in
	  (* id : domty で tyenv を拡張し，その下で exp を型推論 *)
      let (s, ranty) =
        ty_exp (Environment.extend id domty tyenv) exp in
        (s, TyFun (subst_type s domty, ranty))
  | AppExp (exp1, exp2) ->
      let (s1, ty1) = ty_exp tyenv exp1 in
      let (s2, ty2) = ty_exp tyenv exp2 in
      let domty = TyVar (fresh_tyvar ()) in
      let eqs = (ty1, TyFun(ty2, domty)) :: (eqs_of_subst s1) @ (eqs_of_subst s2) in
      let s3 = unify eqs in
      (s3, subst_type s3 domty)
  | _ -> err ("Not Implemented!")

let ty_decl tyenv = function
    Exp e -> let (subst, typ) = ty_exp tyenv e in (tyenv, typ)
  | Decl (id, e) -> let (subst, typ) = ty_exp tyenv e in (tyenv, typ)
  | _ -> err ("Not Implemented!")
