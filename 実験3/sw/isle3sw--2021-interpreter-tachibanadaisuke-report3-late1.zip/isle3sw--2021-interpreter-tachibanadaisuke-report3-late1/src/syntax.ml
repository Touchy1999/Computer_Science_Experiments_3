(* ML interpreter / type reconstruction *)
type id = string
(*Exercise3.2.3 : 論理積、論理和のためのbinOpを追加した*)
type binOp = Plus | Mult | Lt | Seki | Wa

type exp =
    Var of id
  | ILit of int
  | BLit of bool
  | BinOp of binOp * exp * exp
  | IfExp of exp * exp * exp
  | LetExp of id * exp * exp (*Exercise3.3.1 : LetExpの定義を追加した*)
  | FunExp of id * exp (*Exercise3.4.1 : FunExpの定義を追加した*)
  | AppExp of exp * exp (*Exercise3.3.1 : AppExpの定義を追加した*)
  | LetRecExp of id * id * exp * exp (*Exercise3.5.1 : LetRecExpの定義を追加した*)
  | DFunExp of id * exp

type program =
    Exp of exp
  | Decl of id * exp (*Exercise3.3.1 : Declの定義を追加した*)
  | RecDecl of id * id * exp (*Exercise3.5.1 : RecDeclの定義を追加した*)

type tyvar = int (* 型変数の識別子を整数で表現 *)
(* MiniML の型を表す OCaml の値の型 *)
type ty =
    TyInt
  | TyBool
  | TyVar of tyvar (* 型変数型を表すコンストラクタ *)
  | TyFun of ty * ty (* TFun(t1,t2) は関数型 t1 -> t2 を表す *)
  | TyList of ty

(* Exercise4.3.1 : ty に現れる自由な型変数の識別子（つまり，tyvar 型の集合）を返す関数*)
let rec freevar_ty typ = 
  let rec freevar_ty_rec ty_rec set_rec = 
    match ty_rec with
      TyVar var -> MySet.insert var set_rec
    | TyFun (ty1, ty2) -> 
        let set_1 = freevar_ty_rec ty1 set_rec in
        let set_2 = freevar_ty_rec ty2 set_1 in
        set_2
    | TyList ty1 -> freevar_ty_rec ty1 set_rec
    | _ -> set_rec
  in freevar_ty_rec typ MySet.empty

(*Exercise4.3.1 : ty を受け取ってその文字列表現を返す関数*)
let rec string_of_ty ty =
  match ty with
    TyInt -> "int"
  | TyBool -> "bool"
  | TyVar tyvar -> "'a" ^ string_of_int tyvar
  | TyFun (ty1, ty2) -> 
      let to_string ty_sample = 
        (match ty_sample with 
           TyFun(_, _) -> "(" ^ string_of_ty ty_sample ^ ")"
         | _ -> string_of_ty ty_sample) in
      let to_string2 ty_sample2 = string_of_ty ty_sample2 
      in to_string ty1 ^ " -> " ^ to_string2 ty2




(*Exercise4.3.1 :  ty 型の値のための pretty printer *)

let pp_ty typ = print_string (string_of_ty typ)



(* 呼び出すたびに，他とかぶらない新しい tyvar 型の値を返す関数 *)
let fresh_tyvar =
  let counter = ref 0 in (* 次に返すべき tyvar 型の値を参照で持っておいて， *)
  let body () =
    let v = !counter in
      counter := v + 1; v (* 呼び出されたら参照をインクリメントして，古い counter の参照先の値を返す *)
  in body
