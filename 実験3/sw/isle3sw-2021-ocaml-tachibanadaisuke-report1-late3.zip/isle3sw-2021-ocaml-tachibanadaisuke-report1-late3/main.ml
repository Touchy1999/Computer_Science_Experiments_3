(* Exercise 2.1 *)
(*1
type  float
result  5.5
2
type int
result 0
3
type string
result foo
4
type char
result U
5
type int
result 255
6
type float
result 25.
*)
(* Exercise 2.2 *)
(*
1
予想したエラーの原因 : else文を書いていない
コンパイラの解釈した誤りの理由 : else文を書いていないので、int型であるがunit型と評価されている
2
予想したエラーの原因 : -2を()で括っていないため、演算子が連続している
コンパイラの解釈した誤りの理由 : -2を()で括っていないため、*- がひとつの演算子として解釈されてしまっている。
3
予想したエラーの原因 : "0xfg"を()で括っていないので、int_of_string関数が使えない
コンパイラの解釈した誤りの理由 : 0xで始まるので16進数表記となるが、"g"は16進数表記に現れないのでエラーとなる。
4
予想したエラーの原因 : -0.7を()で括っていないので、int_of_float関数が使えない
コンパイラの解釈した誤りの理由 : 0.7は整数として評価されるのでint_of_float関数が使えない。
*)
(* Exercise 2.3 *)
(*
1 : not (true && false)
2 : float_of_int (int_of_float (5.0))
3 : sin (3.14 /. 2.0) ** 2.0 +. cos (3.14 /. 2.0) ** 2.0
4 : int_of_float(sqrt(3. *. 3. +. 4. *. 4.))
*)

(* Exercise 2.4 *)
(*
b1 && b2
if b1 then 
    if b2 then true
    else false
  else false

b1 || b2
if not a then 
    if not b then true
    else false
  else false
*)
(* Exercise 2.5 *)
(* a_2' ,____, _'_'_の3つのみが変数名として有効である*)
(* Exercise 2.6 *)
let yen_of_usdollar n = int_of_float(n *. 111.12000000 +. 0.5)
let usdollar_of_yen n = let dollar = float_of_int(n) /. 111.12 *. 100.0 in floor(dollar +. 0.5) /. 100.0
let yen_of_usdollar_message n = string_of_float(n) ^ " dollars are " ^ string_of_int(yen_of_usdollar(n)) ^ " yen."
let capitalize n = match n with 
     'a' -> 'A'
   | 'b' -> 'B'
   | 'c' -> 'C'
   | 'd' -> 'D'
   | 'e' -> 'E'
   | 'f' -> 'F'
   | 'g' -> 'G'
   | 'h' -> 'H'
   | 'i' -> 'I'
   | 'j' -> 'J'
   | 'k' -> 'K'
   | 'l' -> 'L'
   | 'm' -> 'M'
   | 'n' -> 'N'
   | 'o' -> 'O'
   | 'p' -> 'P'
   | 'q' -> 'Q'
   | 'r' -> 'R'
   | 's' -> 'S'
   | 't' -> 'T'
   | 'u' -> 'U'
   | 'v' -> 'V'
   | 'w' -> 'W'
   | 'x' -> 'X'
   | 'y' -> 'Y'
   | 'z' -> 'Z'
   | _ -> n


(* Exercise 3.1 *)(*
1
予想 : x*x の式は x = x + 2 を参照し、x = x + 2 は x = 3 を参照しているので、結果は25
検証結果 : 上の予想は正しい
2
予想 : y は let y = 3 を参照し、x * y は let y = x and x = y + 2 を参照し、y, x は let x = 2, let y = 3 を参照しているので、結果は13
検証結果 : 上の予想は正しい
3
予想 : x は let x = 2 , y は let y = x , z は let z = y + 2 の定義を参照するので、結果は16
検証結果 : 上の予想は正しい*)
(* Exercise 3.2 *)(*
e2がxを含む式であるとき、上の式ではxが定義されていないのでエラーが出るが、下ではすでにxが定義されているのでその値が用いられる。*)
(* Exercise 3.3 *)
let geo_mean (a, b) = sqrt(a*.b)

(* Exercise 3.4 *)
(*let prodMatVec(a11, a12, a21, a22, b11, b21) = (a11 *. b11 +. a12 *. b21, a21 *. b11 +. a22 *. b21)*)
(*2行2列の実数行列の要素を行列の定義と同様にそれぞれa11,a12,a21,a22と定義している。また、実数ベクトルの要素も同様にb11,b21と定義した。これらを組として計算を行った。*)

(* Exercise 3.5 *)
(*float * float * float * float は 4つの実数要素を持つの組で、 let x = (1. , 2., 3., 4.) などの式で構成される一方、
(float * float) * (float * float) は2つの実数要素を持つ組を二つ、それらを組として構成したもので、 let y = ((1., 2.), (3., 4.))などの式が例である。
また、要素の取り出し方は前者では let (a, b, c, d) = x などのように行い、後者では let ((a, b), (c, d)) = y などのように行うという違いがある。*)
(* Exercise 3.6 *)
(*let (x : int) = 3 などの式のようにxがintにマッチするとき、xをint型に明示的に束縛する。*)

(* Exercise 3.7 *)
let rec pow1 (x, n) = if n = 0 then 1.0 else x *. pow1 (x, n-1)
let rec pow2 (x, n) = if n = 0 then 1.0 else if n mod 2 = 0 then pow2(x*.x,n/2) else pow2(x,n-1) *. x

(* Exercise 3.8 *)
let rec sub_powi x n res =
  if n = 0 then res
  else sub_powi x (n-1) (x *. res)

let rec powi (x, n) = sub_powi x n 1.0

(* Exercise 3.9 *)
(*ocamlでは関数の引数が先に評価されるので、fact 4 の値を確定させる前に fact 3,fact 3 の値を確定させる前に fact 2, fact 2 の値を確定させる前に fact 1, 
fact 1 の値を確定させる前に fact 0, fact 0 の値を確定させる前に fact -1, ... の値を評価しようとしてStack Overflowになるから。*)

(* Exercise 3.10 *)
(*
fib 4 → fib 3 + fib 2 
      → fib 2 + fib 1 + fib 2
      → 1 + 1 + 1
      → 3 
*)

(* Exercise 3.11(1) *)
let rec gcd (m, n) =
  if m = 0 then n
  else if n = 0 then m
  else 
  if m = n then m
  else if m > n then gcd (n, m)
  else gcd (n mod m, m)

(* Exercise 3.11(2) *)
let rec comb (n, m) =
  if m = 0 then 1
  else if m = n then 1
  else comb(n-1, m) + comb(n-1, m-1)

(* Exercise 3.11(3) *)

let rec fib_pair n (prev, curr) = 
  if n = 1 then curr
  else fib_pair (n-1) (curr, prev+curr)


let fib_iter n = fib_pair n (0, 1)

(* Exercise 3.11(4) *)
let max_ascii str =
  let rec iter max i =
    if String.length str == i then
      max
    else if max < str.[i] then
      iter str.[i] (i + 1)
    else
      iter max (i + 1)
  in iter str.[0] 0

(* Exercise 3.12 *)
let rec arctan_one n = 
  if n < 0 then 0.0
  else arctan_one (n-1) +. 1.0 /. float_of_int((4*n+1)) -.  1.0 /. float_of_int((4*n+3))

(* Exercise 4.1 *)
let integral f a b = 
  let n = 100000000 in
  let delta = (b -. a) /. float_of_int(n) in
  let x i = a +. float_of_int(i) *. delta in
  let y i = f (x i) in
  let delta_area i =
    (y (i - 1) +. y i) *. delta /. 2.0
  in
  let rec loop i acc =
    if x i > b then acc
    else loop (i + 1) (delta_area i +. acc)
  in loop 1 0.0;;

(* Exercise 4.2 *)
let rec pow_curry n = fun x -> if n = 0 then 1. else x *. pow_curry (n-1) x
let cube n = pow_curry 3 n

(*let cube n = pow_curry n 3 と表記すればよい*)

(* Exercise 4.3 *)
(*
・let g x y z = x + y + z
t1 -> (t2 -> (t3 -> t4))という意味で、t1を受け取って、(t2を受け取って、(t3を受け取ってt4を返す)を返す)を返す
・let deriv f = fun x -> f(x + 1) - f(x)
(t1 -> t2) -> (t3 -> t4)という意味で、(t1を受け取って、t2を返す)を受け取って、(t3を受け取って、t4を返す)を返す
・let g (f:int -> int -> int) = f 1 2
(t1 -> (t2 -> t3)) -> t4という意味で、(t1を受け取って、(t2を受け取ってt3を返す)を返す)を受け取って、t4を返す
*)

(* Exercise 4.4 *)
let uncurry f (x, y) = f x y

(* Exercise 4.5 *)
let rec repeat f n x =
  if n > 0 then repeat f (n - 1) (f x) else x

let fib_repeat n =
  let (fibn, _) = repeat (fun (a,b) -> (b,a+b)) n (0,1)
  in fibn

(* Exercise 4.6 *)
(*n の回数だけ、f関数を繰り返す関数を返す関数である*)

(* Exercise 4.7 *)
(*s k k 1 → k 1 (k 1)
          → 1となり、s k k が恒等関数として機能することが分かる。*)
(*k (s k k) 1 2;;*)
let k x y = x
let s x y z = x z (y z)
let second x y = (k (s k k)) x y

(* Exercise 4.8 *)
(*double double f x →
  double (double f) x →
  (double f (double f x)) →
  double f f(f x) →
  f(f(f(f x)))
これはxにfを4回適用する関数であり、f(f(f(f(x))))と同じである。*)

(* Exercise 5.1 *)
(*
1
予想 : 空リストのリストなので型は 'a list
結果 : 上の予想は誤り。型は 'a list list
2
予想 : 整数のリストと文字列のリストのリストなので、エラー
結果 : 上の予想は正しい
3
予想 : 空リストに整数のリストを加えたなので、型は int list
結果 : 上の予想は誤り。型は int list list
4
予想 : 整数のリストに整数を加えているので、型は int list
結果 : 上の予想は誤り。整数のリストのリストに整数を加えているのでエラー
5
予想 :  空リストに空リストを加えたなので、型は 'a list
結果 : 上の予想は誤り。型は 'a list list
6
予想 : 関数のリストとbool型の関数のリストなので、型は (bool -> bool) list
結果 : 上の予想は正しい
*)

(* Exercise 5.2 *)
let hd (x::rest) = x

let tl (x::rest) = rest

let null = function [] -> true | _ -> false

let rec sum_list l = 
  if null l then 0
  else hd l + sum_list(tl l)

let rec max_list l =
  if null (tl l) then hd l
  else
    let n1 = hd l
    and n2 = hd (tl l)
    and rest = tl (tl l) in
    if n1 > n2 then max_list (n1 :: rest)
    else max_list (n2 :: rest)

(*matchを使わないで実装しようとすると、n1,n2,restのバインディングにかなり苦労する。*)

(* Exercise 5.3(1) *)
let rec downto0 n =
  match n with
  -1-> []
  | _ -> n :: downto0 (n-1)

(* Exercise 5.3(2) *)
let rec f_a a = function 
    (a', b) :: rest -> if a = 1 then a' else f_a (a-1) rest

let rec f_b a = function 
    (a', b) :: rest -> if a = 1 then b else f_b (a-1) rest

let rec roman l n =
  if n = 0 then ""
  else if n >= f_a 1 l then f_b 1 l ^ roman l (n-(f_a 1 l))
  else roman (tl(l)) n

(* Exercise 5.3(3) *)
let rec fold_left f e l =
  match l with
    [] -> e
  | x :: rest -> List.fold_left f (f e x) rest

let concat l = fold_left (@) [] l

(* Exercise 5.3(4) *)
let rec zip l1 l2 =
    match l1, l2 with 
      [], _ -> []
    | _, [] -> []
    | x::x_rest, y::y_rest -> (x, y) :: zip x_rest y_rest

(* Exercise 5.3(5) *)

let rec length = function
    [] -> 0
  | _ :: rest -> 1 + length rest

let rec filter p l = 
  match l with
    [] -> []
  | x :: xs -> 
      if p x then x :: filter p xs
      else filter p xs

(* Exercise 5.3(6) *)
let rec belong a s = 
  match s with
    [] -> false
  | x :: xs -> 
      if x = a then true
      else belong a xs

let rec intersect s1 s2 = 
  match s1 with
    []-> []
  | x :: xs -> 
      if belong x s2 then x :: intersect xs s2
      else intersect xs s2

let rec union s1 s2 = 
  match s1 with
    []-> s2
  | x :: xs -> 
      if belong x s2 then union xs s2
      else x :: union xs s2

let rec delete a l = 
  match l with 
    [] -> []
  | x :: xs -> 
      if x = a then delete a xs
      else x :: delete a xs

let rec diff s1 s2 = 
  match s2 with
    [] -> s1
  | x :: xs -> 
      if  belong x s1 then diff (delete x s1) xs 
      else diff s1 xs

(* Exercise 5.4 *)
(*map (fun x -> f(g(x))) l*)

(* Exercise 5.5 *)
let rec fold_right f l e =
  match l with
    [] -> e
  | x :: rest -> f x (fold_right f rest e)

let rec map f = function
    [] -> []
  | x :: rest -> f x :: map f rest
  
let forall prop l = fold_right (&&) (map prop l) true
let exists prop l = fold_right (||) (map prop l) false

(* Exercise 5.6 *)

let rec quicker l sorted = 
  match l with
    [] -> sorted
  | [x] -> x :: sorted
  | x :: xs -> 
      let rec partition left right = function
          [] -> quicker left (x :: quicker right sorted)
        | y :: ys -> if x < y then partition left (y :: right) ys
            else partition (y :: left) right ys in
      partition [] [] xs
let quick l = quicker l []

(* Exercise 5.7 *)
let squares _ = assert false

(* Exercise 5.8 *)
let map2 _ = assert false

(* Exercise 6.1 *)
type figure = Point | Circle of int | Rectangle of int * int | Square of int
type loc_fig = { x : int; y : int; fig : figure; }
let overlap lf1 lf2 = 
  let x1 = lf1.x in 
  let y1 = lf1.y in 
  let fig_1 = lf1.fig in 
  let x2 = lf2.x in 
  let y2 = lf2.y in 
  let fig_2 = lf2.fig in
  let f x y z w = (x-z)*(x-z) + (y-w)*(y-w) in
  let p_and_r xp yp xr yr w h = 
    (xr <= xp) && (xp <= xr+w) && (yr <= yp) && (yp <= yr+h) in
  
  let r_and_r x1 y1 w1 h1 x2 y2 w2 h2 =
    (x1 <= x2+w2) && (x2 <= x1+w1) && 
    (y1 <= y2+h2) && (y2 <= y1+h1) in 
  
  let rectangle_and_circle xr yr w h xc yc rc = 
    let a1 = xr-rc <= xc && xc <= xr+w+rc 
             && yr <= yc && yc <= yr+h in
    let a2 = xr <= xc && xc <= xr+w 
             && yr-rc <= yc && yc <= yr+h+rc in
    let a3 = xr-rc <= xc && xc <= xr && 
             yr+h <= yc && yc <= yr+h+rc && 
             f xc yc xr (yr+h) <= rc*rc in
    let a4 = xr-rc <= xc && xc <= xr &&
             yr-rc <= yc && yc <= yr &&
             f xc yc xr yr <= rc*rc in
    let a5 = xr+w <= xc && xc <= xr+w+rc &&
             yr-rc <= yc && yc <= yr && 
             f xc yc (xr+w) yr <= rc*rc in
    let a6 = xr+w <= xc && xc <= xr+w+rc &&
             yr+h <= yc && yc <= yr+h+rc && 
             f xc yc (xr+w) (yr+h) <= rc*rc in
    a1 || a2 || a3 || a4 || a5 || a6 in
  
  match (fig_1, fig_2) with 
    (Point, Point) -> 
      if (x1 = x2) && (y1 = y2) then true else false 
  | (Point, Circle (r_c)) -> 
      f x1 y1 x2 y2 <= r_c*r_c
  | (Point, Rectangle (r_1, r_2)) -> 
      p_and_r x1 y1 x2 y2 r_1 r_2
  | (Point, Square (r_1)) -> 
      p_and_r x1 y1 x2 y2 r_1 r_1
  | (Circle (r_c), Point) -> 
      f x1 y1 x2 y2 <= r_c*r_c
  | (Circle (r_1), Circle (r_2)) ->
      f x1 y1 x2 y2 <= (r_1 + r_2)*(r_1 + r_2) 
  | (Circle (r_1), Rectangle (r_2, r_3)) -> 
      rectangle_and_circle x2 y2 r_2 r_3 x1 y1 r_1 
  | (Circle (r_1), Square (r_2)) -> 
      rectangle_and_circle x2 y2 r_2 r_2 x1 y1 r_1 
  | (Rectangle (r_1, r_2), Point) -> 
      p_and_r x2 y2 x1 y1 r_1 r_2
  | (Rectangle (r_1, r_2), Circle (r_3)) -> 
      rectangle_and_circle x1 y1 r_1 r_2 x2 y2 r_3 
  | (Rectangle (r_1, r_2), Rectangle (r_3, r_4)) -> 
      r_and_r x1 y1 r_1 r_2 x2 y2 r_3 r_4
  | (Rectangle (r_1, r_2), Square (r_3)) -> 
      r_and_r x1 y1 r_1 r_2 x2 y2 r_3 r_3
  | (Square (r_1), Point) -> 
      p_and_r x2 y2 x1 y1 r_1 r_1
  | (Square (r_1), Circle (r_3)) ->
      rectangle_and_circle x1 y1 r_1 r_1 x2 y2 r_3 
  | (Square (r_1), Rectangle (r_2, r_3)) -> 
      r_and_r x1 y1 r_1 r_1 x2 y2 r_2 r_3
  | (Square (r_1), Square (r_2)) -> 
      r_and_r x1 y1 r_1 r_1 x2 y2 r_2 r_2
      
(* Exercise 6.2 *)
type nat = Zero | OneMoreThan of nat
let rec int_of_nat n = 
  match n with
    Zero -> 0
  | OneMoreThan n' -> 1 + int_of_nat n'

let rec add m n =
  match m with Zero -> n | OneMoreThan m' -> OneMoreThan (add m' n)

let rec mul n1 n2 = 
  match n1 with 
    Zero -> Zero
  | OneMoreThan n1' -> 
      match n2 with
        Zero -> Zero
      | OneMoreThan n2' -> 
          let x = add n1' n2' in
          let y = add (OneMoreThan (Zero))  (mul n1' n2') in
          add x y

let rec monus n1 n2 = 
  match n2 with 
    Zero -> n1
  | OneMoreThan n2' -> 
      match n1 with
        Zero -> Zero
      | OneMoreThan n1' -> monus n1' n2'

(* Exercise 6.3 *)
let rec minus n1 n2 = 
  match (n1, n2) with 
    (Zero, Zero) -> Some Zero
  | (_, Zero) -> Some n1
  | (Zero, _) -> None
  | (OneMoreThan n1', OneMoreThan n2') -> minus n1' n2'

(* Exercise 6.4 *)
type 'a tree = Lf | Br of 'a * 'a tree * 'a tree
let rec comptree x n = 
  match n with 
    0 -> Lf
  | _ -> Br(x, comptree x (n-1), comptree x (n-1))

(* Exercise 6.5 *)
let rec inord' t l =
  match t with
    Lf -> l
  | Br(x, left, right) -> inord' (left) (x :: (inord' right l))

let rec inord t = inord' t []

let rec postord' t l =
  match t with
    Lf -> l
  | Br(x, left, right) -> postord' left (postord' right (x::l))

let rec postord t = postord' t []

(* Exercise 6.6 *)
let rec reflect tr = 
  match tr with
    Lf -> Lf
  | Br (n, left, right) -> Br (n, reflect(right), reflect(left))

  (*
  preorder(reflect(t)) = revAppend (postorder(t)) []
  inorder(reflect(t)) = revAppend (inorder(t)) []
  postorder(reflect(t)) = revAppend (preorder(t)) []
  *)

(* Exercise 6.7 *)
type arith = Const of int | Add of arith * arith | Mul of arith * arith

let rec string_of_arith a = 
  match a with 
    Const n -> string_of_int(n)
  | Add (n1, n2) -> string_of_arith(n1) ^ "+" ^ string_of_arith(n2)
  | Mul (n1, n2) -> 
      let f = function
          Add _ as x -> "(" ^ string_of_arith (x) ^ ")"
        | x -> string_of_arith (x)
      in f(n1) ^ "*" ^ f(n2) 
(*
let rec expand = function 
    Const n -> Const n
  | Add (n, m) -> Add (expand n, expand m)
  | Mul (n, m) -> 
      match (n, m) with
        Add (n1, n2), Add (n3 , n4) -> 
          Add (Add (expand (Mul (n1, n3)), expand (Mul (n1, n4))),
               Add (expand (Mul (n2, n3)), expand (Mul (n2, n4))))
      | Mul (n1, n2), Add (n3 , n4) -> 
          Add (Mul (expand (Mul (n1, n2)), expand n3), 
               Mul (expand (Mul (n1, n2)), expand n4))
      | Add (n1, n2), Mul (n3 , n4) -> 
          Add (Mul (expand n1, expand (Mul (n3, n4))), 
               Mul (expand n2, expand (Mul (n3, n4))))
      | Add (n1, n2), Const n3 -> 
          Add (expand (Mul (n1, Const n3)), expand (Mul (n2, Const n3)))
      | Const n1, Add (n2 , n3) -> 
          Add (expand (Mul (Const n1, n2)), expand (Mul (Const n1, n3)))
      | Mul (n1, n2), Mul (n3 , n4) -> 
          Mul (expand (Mul (n1, n2)), expand (Mul (n3, n4)))
      | Mul (n1, n2), Const n3 -> 
          Mul (expand (Mul (n1, n2)), Const n3)
      | Const n1, Mul (n2 , n3) -> 
          Mul (Const n1, expand (Mul (n2, n3)))
      | Const n1, Const n2 ->
          Mul (expand (Const n1), expand (Const n2))
*)
let rec expand = function
    Mul (a, Add (b, c)) ->
      let (a', b', c') = (expand a, expand b, expand c) in
      Add (expand (Mul (a', b')), expand (Mul (a', c')))
  | Mul (Add (a, b), c) ->
      let (a', b', c') = (expand a, expand b, expand c) in
      Add (expand (Mul (a', c')), expand (Mul (b', c')))
  | Add (a, b) -> Add (expand a, expand b)
  | a -> a

(* Exercise 6.8 *)
(*
 Br (1, Lf, Br (2, Lf, Br (3, Lf, Br (4, Lf, Lf))))　
 1,2,3,4

 Br (2, Br (1, Lf, Lf), Br (3, Lf, Br (4, Lf, Lf)))
 2,1,3,4

 Br (1, Lf, Br (3, Br (2, Lf, Lf), Br (4, Lf, Lf)))
 1,3,2,4

 Br (3, Br (1, Lf, Br (2, Lf, Lf)), Br (4, Lf, Lf))
 3,1,2,4

 Br (3, Br (2, Br (1, Lf, Lf), Lf), Br (4, Lf, Lf))
 3,2,1,4

 Br (1, Lf, Br (2, Lf, Br (4, Br (3, Lf, Lf), Lf)))
 1,2,4,3

 Br (2, Br (1, Lf, Lf), Br (4, Br (3, Lf, Lf), Lf))
 2,1,4,3

 Br (1, Lf, Br (4, Br (2, Lf, Br (3, Lf, Lf)), Lf))
 1,4,2,3

 Br (4, Br (1, Lf, Br (2, Lf, Br (3, Lf, Lf))), Lf)
 4,1,2,3

 Br (4, Br (2, Br (1, Lf, Lf), Br (3, Lf, Lf)), Lf)
 4,2,1,3

 Br (1, Lf, Br (4, Br (3, Br (2, Lf, Lf), Lf), Lf))
 1,4,3,2

 Br (4, Br (1, Lf, Br (3, Br (2, Lf, Lf), Lf)), Lf)
 4,1,3,2

 Br (4, Br (3, Br (1, Lf, Br (2, Lf, Lf)), Lf), Lf)
 4,3,1,2

 Br (4, Br (3, Br (2, Br (1, Lf, Lf), Lf), Lf), Lf)
 4,3,2,1

 以上14種類存在する。
*)

(* Exercise 6.9 *)
type 'a seq = Cons of 'a * (unit -> 'a seq);;

let head (Cons (x, _)) = x;;
let tail (Cons (_, f)) = f ();;
let rec take n s =
  if n = 0 then [] else head s :: take (n-1) (tail s);;

let rec from n = Cons (n, fun () -> from (n+1));;

let rec sift n (Cons (x, f)) =
  if (x mod n) = 0 then sift n (f ())
  else Cons (x, fun () -> sift n (f ()))
;;

let rec sieve (Cons (x, f)) = Cons (x, fun () -> sieve (sift x (f ())));;

let primes = sieve (from 2);;

let rec nthseq n (Cons (x, f)) =
  if n = 1 then x
  else nthseq (n-1) (f())
;;

(*学生番号が1029316811なので nthseq 9811 primes;; で求められる。*)

type ('a, 'b) sum = Left of 'a | Right of 'b

(* Exercise 6.10(1) *)
let f1 (a, x) =
  match x with
    Left b ->  Left (a, b)
  | Right c -> Right (a, c)

(* Exercise 6.10(2) *)
let f2 (x, y) =
  match x, y with
  | Left xl, Left yl -> Left (Left (xl, yl))
  | Left xl, Right yr -> Right (Left (xl, yr))
  | Right xr, Left yl -> Right (Right (xr, yl))
  | Right xr, Right yr -> Left (Right (xr, yr))

(* Exercise 6.10(3) *)
let f3 _ = assert false

(* Exercise 6.10(4) *)
let f4 _ = assert false

(* Exercise 6.10(5) *)
let f5 _ = assert false

(* Exercise 7.1 *)
type 'a ref = { mutable contents:'a }

let ref x = {contents = x}
let (!) x = x.contents
let (:=) x y = x.contents <- y
                                   
(* Exercise 7.2 *)
let incr n = n := !n + 1

(* Exercise 7.3 *)
(*fは引数に1を加えた整数を返す関数であるが、後で書き換えるので整数から整数を返す関数ならなんでもよい。関数funny_factでは!fで(x-1)を引数として関数fを実行する。f := funnyfact という式によってfunny_factの中のfは
funny_factということになる。*)

(* Exercise 7.4 *)
let fact_imp n =
  let i = ref n and res = ref 1 in
  while (!i >= 1) do
    res := !res * !i;
    i := !i - 1
  done;
  ! res

(* Exercise 7.5 *)

let rec make_fact n = 
  match n with 
    0 -> 1
  | _ -> n * make_fact(n-1);;

exception Invalid_argument;;

let fact_safety n = 
  if n < 0 then raise Invalid_argument
  else make_fact n

(* Exercise 7.6 *)
(*
# let x = ref [];;
val x : '_a list ref = {contents = []}
# (2 :: !x, true :: !x);;
Characters 18-20:
  (2 :: !x, true :: !x);;
                    ^^
Error: This expression has type int list
       but an expression was expected of type bool list
( 2:: !x )の時点で、x : int list ref になっているため、true :: !xを
しようとすると、異なるタイプのリストが作成されるため、型エラーになる。
*)

(* Exercise 7.7 *)
(*
type color = Blue | Red | Green | White;;

type cpointI = {cget: unit -> int;
                cset: int -> unit;
                cinc: unit->unit;
                getcolor: unit-> color};;

type pointI = {get: unit -> int; set: int -> unit; inc: unit->unit};;

let pointC x =
  let rec this () =
    {get= (fun () -> !x);
     set= (fun newx -> x:=newx);
     inc= (fun () -> (this ()).set ((this ()).get () + 1))} in
  this ();;

let cpointC x col=
  let super = pointC x in
  let rec this =
    {cget= super.get;
     cset= (fun x -> super.set x; col := White);
     cinc= (fun x -> super.inc x; col := White);
     getcolor = (fun () -> !col)} in
  this;;

let new_cpoint x col = cpointC (ref x) (ref col);;

let cp = new_cpoint 0 Red;;

cp.cinc();;

cp.cget();;

cp.getcolor();;

csetに色を白に変更する式を書くだけでは不十分であるから。cincにも色の変更をする式を
追加することで正しい動作をするようになる。

*)

(* Exercise 7.8 *)

let rec change = function
    (_, 0) -> []
  | ((c :: rest) as coins, total) ->
      if c > total then change (rest, total)
      else
        (try
           c :: change (coins, total - c)
         with Failure "change" -> change (rest, total))
  | _ -> raise (Failure "change")

  (*先頭にあるコインを使い切ろうとして組み合わせができないときは先頭のコインを使わず、次に値の小さいコインを一つ用いて、残りの金額を評価する。それでも組み合わせができないときはエラーとなる。*)
