open Miniml.Cui

let _ = read_eval_print initial_env initial_tyenv initial_tyvenv initial_varenv initial_recenv
