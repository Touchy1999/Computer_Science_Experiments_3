open Miniml.Cui
(*
let _ = read_eval_print initial_env
*)
(* initial_tyenv を REPL の最初の呼び出しで渡す *)
let _ = read_eval_print initial_env initial_tyenv