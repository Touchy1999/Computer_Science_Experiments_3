let subst_type _ =
  assert false (* Exercise 4.3.2 *)

let unify _ =
  assert false (* Exercise 4.3.3 *)

let ty_decl _ =
  assert false (* Exercise 4.3.5 *)
