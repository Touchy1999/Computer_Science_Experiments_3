open Syntax

(*Exercise3.4.1,3.5.1 : パラメータ名、関数本体の式、本体中のパラメータで束縛されていない変数（自由変数）の束縛情報をもつ、関数値のためのコンストラクタProcVを定義した、関数閉包内の環境を参照型で保持するように変更*)
(*Exercise3.4.5 : DProcVを追加した**)
type exval =
    IntV of int
  | BoolV of bool
  | ProcV of id * exp * dnval Environment.t ref
  | DProcV of id * exp 
and dnval = exval

exception Error of string

let err s = raise (Error s)

(*Exercise3.4.1 : 関数を文字列化するため、 string_of_exval 関数に ProcV が与えられた場合に "<fun>" が返るようにした*)
(*Exercise3.4.5 : 関数を文字列化するため、 string_of_exval 関数に DProcV が与えられた場合に "<dfun>" が返るようにした*)
(* pretty printing *)
let rec string_of_exval = function
    IntV i -> string_of_int i
  | BoolV b -> string_of_bool b
  | ProcV (_, _, _) -> "<fun>"
  | DProcV (_, _) -> "<dfun>"

let pp_val v = print_string (string_of_exval v)

(*Exercise 3.2.3 : 二項演算子のための記述を追加した*)
let rec apply_prim op arg1 arg2 = match op, arg1, arg2 with
    Plus, IntV i1, IntV i2 -> IntV (i1 + i2)
  | Plus, _, _ -> err ("Both arguments must be integer: +")
  | Mult, IntV i1, IntV i2 -> IntV (i1 * i2)
  | Mult, _, _ -> err ("Both arguments must be integer: *")
  | Lt, IntV i1, IntV i2 -> BoolV (i1 < i2)
  | Lt, _, _ -> err ("Both arguments must be integer: <")
  | Seki, BoolV i1, BoolV i2 -> BoolV (i1 && i2) 
  | Seki, _, _ -> err ("Both arguments must be boolean: &&")
  | Wa, BoolV i1, BoolV i2 -> BoolV (i1 || i2)  
  | Wa, _, _ -> err ("Both arguments must be boolean: ||")


  let rec eval_exp env = function
  Var x ->
  (try Environment.lookup x env with
     Environment.Not_bound -> err ("Variable not bound: " ^ x))
| ILit i -> IntV i
| BLit b -> BoolV b
(*定義されていない変数undefのためにまず演算対象の一つ目を評価し、undefによるエラーの発生を防止した*)
| BinOp (op, exp1, exp2) ->
  let arg1 = eval_exp env exp1 in
  (match op with 
     Seki -> 
       (match arg1 with
          BoolV false -> BoolV false
        | BoolV true -> let arg2 = eval_exp env exp2 in apply_prim op arg1 arg2)
   | Wa -> 
       (match arg1 with
          BoolV false -> let arg2 = eval_exp env exp2 in apply_prim op arg1 arg2
        | BoolV true -> BoolV true)
   | _ -> 
       let arg2 = eval_exp env exp2 in apply_prim op arg1 arg2)
  (* 関数定義式: 現在の環境 env をクロージャ内に保存 *)
  | FunExp (id, exp) -> ProcV (id, exp, ref env)
  | DFunExp (id, exp) -> DProcV (id, exp)
  (* 関数適用式 *)
  | AppExp (exp1, exp2) ->
    (* 関数 exp1 を現在の環境で評価 *)
    let funval = eval_exp env exp1 in
     (* 実引数 exp2 を現在の環境で評価 *)
    let arg = eval_exp env exp2 in
    (* 関数 exp1 の評価結果をパターンマッチで取り出す *)
    (match funval with
        ProcV (id, body, env') -> (* 評価結果が実際にクロージャであれば *)
            (* クロージャ内の環境を取り出して仮引数に対する束縛で拡張 *)
            let newenv = Environment.extend id arg env'.contents in
              eval_exp newenv body
      (*Exercise3.4.5 : 動的束縛をProcVと同様に実装した**)
      | DProcV (id, body) ->
        let newenv = Environment.extend id arg env in
              eval_exp newenv body
      | _ -> 
      (* 評価結果がクロージャでなければ，実行時型エラー *)
        err ("Non-function value is applied"))

| IfExp (exp1, exp2, exp3) ->
  let test = eval_exp env exp1 in
  (match test with
     BoolV true -> eval_exp env exp2
   | BoolV false -> eval_exp env exp3
   | _ -> err ("Test expression must be boolean: if"))

| LetExp (id, exp1, exp2) ->
(* 現在の環境で exp1 を評価 *)
      let value = eval_exp env exp1 in
       (* exp1 の評価結果を id の値として環境に追加して exp2 を評価 *)
      eval_exp (Environment.extend id value env) exp2

| LetRecExp (id, para, exp1, exp2) ->
(* ダミーの環境への参照を作る *)
   let dummyenv = ref Environment.empty in
   (* 関数閉包を作り，idをこの関数閉包に写像するように現在の環境envを拡張 *)
   let newenv = Environment.extend id (ProcV (para, exp1, dummyenv)) env in
     (* ダミーの環境への参照に，拡張された環境を破壊的代入してバックパッチ *)
     dummyenv := newenv;
     eval_exp newenv exp2

let eval_decl env = function
    Exp e -> let v = eval_exp env e in ("-", env, v)
  | Decl (id, e) ->
      let v = eval_exp env e in (id, Environment.extend id v env, v)
  | RecDecl (id, para, exp) ->
      let dummyenv = ref Environment.empty in
          let v = ProcV (para, exp, dummyenv) in
          let newenv = Environment.extend id v env in
            dummyenv := newenv;
            ("-", newenv, v)
