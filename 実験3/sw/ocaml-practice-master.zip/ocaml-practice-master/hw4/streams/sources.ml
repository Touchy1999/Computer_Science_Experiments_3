#use "stream.ml";;
#use "series.ml";;
#use "pascal.ml";;