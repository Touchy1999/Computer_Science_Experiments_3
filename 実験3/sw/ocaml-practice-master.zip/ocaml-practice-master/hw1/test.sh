ocamlc -o hw1 hw1.ml
./hw1