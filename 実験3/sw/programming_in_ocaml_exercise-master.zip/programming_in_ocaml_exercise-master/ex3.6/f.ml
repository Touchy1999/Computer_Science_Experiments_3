let sum_and_diff (x, y) = (x + y, x - y);;
let f (x, y) = ((x + y) / 2, (x - y) / 2);;
