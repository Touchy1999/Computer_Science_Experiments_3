let geo_mean (x, y) = sqrt ( x *. y );;
