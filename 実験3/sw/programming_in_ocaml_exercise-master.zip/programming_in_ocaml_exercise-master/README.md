# Exercise of Programming in OCaml
* This repository is only for the records of the learning with the book `Programming in OCaml`
* See about the book: [プログラミング in OCaml ~関数型プログラミングの基礎からGUI構築まで~](http://www.amazon.co.jp/gp/product/4774132640/ref=as_li_qf_sp_asin_tl?ie=UTF8&camp=247&creative=1211&creativeASIN=4774132640&linkCode=as2&tag=gunjinikkisol-22)
* Please let me know or send a pull request if you have any better solutions. See [解答がわからない問題などはIssueを参照](https://github.com/kaznum/programming_in_ocaml_exercise/issues)

