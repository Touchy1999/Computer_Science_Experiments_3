let orig_and b1 b2 =
  b1 && b2;;

let answer_and b1 b2 =
  if b1 then b2 else false;;

let orig_or b1 b2 =
  b1 || b2;;

let answer_or b1 b2 =
  if b1 then true else b2;;


