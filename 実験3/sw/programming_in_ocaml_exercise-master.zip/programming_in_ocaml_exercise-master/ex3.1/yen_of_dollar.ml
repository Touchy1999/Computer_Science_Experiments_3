let yen_of_dollar dollar = 
  let rate = 114.32 in
  int_of_float ( rate *. dollar );;
