open Fact
let () = print_int (fact 10); print_newline ()
