let cone_of_heightTwo r =
  let base = r *. r *. 3.14 in
  base *. 2.0 /. 3.0;;

