let area_of_circle(r : float) : float = (* 円の面積 *)
  r *. r *. pi;;

